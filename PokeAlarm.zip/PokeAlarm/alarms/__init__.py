#!/usr/bin/python
# -*- coding: utf-8 -*-

config = {
	'LOCALE': 'en',
	'LOCALES_DIR': 'locales',
	'ROOT_PATH': '',
	'HOST':'127.0.0.1',
	'PORT':'4000',
	'SKIP_LURED':False
}

from utils import  *
